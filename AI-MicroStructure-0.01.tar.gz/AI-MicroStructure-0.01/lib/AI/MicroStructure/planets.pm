package AI::MicroStructure::planets;
use strict;
use AI::MicroStructure::Locale;
our @ISA = qw( AI::MicroStructure::Locale );
__PACKAGE__->init();
1;


__DATA__
# default
en
# names de
Merkur Venus Erde Mars Jupiter Saturn Uranus Neptun
# names en
Mercury Venus Earth Mars Jupiter Saturn Uranus Neptune
