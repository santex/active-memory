package AI::MicroStructure::foo;
use strict;
use AI::MicroStructure::Locale;
our @ISA = qw( AI::MicroStructure::Locale );
__PACKAGE__->init();
1;
__DATA__
# default
en
# names en
foo    bar   baz
